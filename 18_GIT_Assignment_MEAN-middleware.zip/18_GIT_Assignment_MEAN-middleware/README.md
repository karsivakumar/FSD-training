# 13-NODE.JS Assignment 2 MEAN

To run the application make sure MySQL and Nodejs is installed.

Please see the respective READMEs of e-stationarymart-backend and e-stationarymart-ui to run the backend and the frontend of the application respectively.