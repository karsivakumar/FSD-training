# E-Stationary Mart Backend

To run the Backend create a file conig.js with following contents:
```
const config = {
    host: "localhost",
    user: "<mysql username>",
    password: "<mysql password>",
    database: "eMart",
    serverport: 3000,
};

module.exports = config;
```

Now run `npm install && npm start` command.