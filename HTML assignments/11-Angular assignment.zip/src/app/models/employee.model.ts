export class Employee {
    name: string;
    age: number;
    email: string;
}
