const fs = require('fs');
const http = require('http');
const calculator = require('./calculator');
var inpChoiceData1 = 0;

console.log(` enter your choice in the input.txt file:, default choice is 1,`);

console.log(`1. calculator`);
console.log(`2. read data from a file`);
console.log(`3. read data from a file and write to another file`);
console.log(`4. read data from a HTML file on port 8444 and display the contents`);
console.log(`5. read data from a json file "sample.json" and dsiplay on the browser`);

fs.readFile('./input.txt', 'utf8', (err, inpChoiceData) => {
    if (err) {
        console.log(err)
    }
        else
    {
    console.log(`The function choice in the input file is :`,inpChoiceData);
    inpChoiceData1 = inpChoiceData;
    console.log(inpChoiceData1);

    if (inpChoiceData1 == 1) {
        /* 
            1. Write a program to create a module and develop a calculator
        */
            var a = 3.5, b = 2.5;
            console.log(`Addition of ${a} & ${b}: `, calculator.add(a, b));
            console.log(`Subtraction of ${a} & ${b}: `, calculator.sub(a, b));
            console.log(`Multiplication of ${a} & ${b}: `, calculator.mul(a, b));
            console.log(`Division of ${a} & ${b}: `, calculator.div(a, b));
            console.log(`Division of ${a} & ${b}: `, calculator.div(a, 0));
            console.log(`Power of ${a} & ${b}: `, calculator.pow(a, b));
            
            console.log('-------------------');
            
        } else 
        if (inpChoiceData1 == 2) {
        /* 
            2. Read data from a file and display the same.
        */
        console.log("The sample.txt contains: ")
        fs.readFile('./sample.txt', 'utf8', (err, data) => {
            if (err) console.log(err)
            console.log(data)
            console.log('-------------------')
        }
        )
        }
        else 
        if (inpChoiceData1 == 3) {
        console.log('-------------------');
        /* 
            3. Read data from a file and write data into another file.
        */
        fs.readFile('./sample.txt', 'utf8', (err, data) => {
            fs.writeFile('./sample-copy.txt', data, 'utf-8', (err) => {
                if (err) console.log(err);
                else console.log('sample-copy.txt create is successful');
            });
        });
        
        console.log('-------------------');
        } else if (inpChoiceData1 == 4) {
                /* 
                    4. Write a html file output to the browser 
                */
                console.log('-------------------');
               console.log('please open http://localhost:8444 to read the data!');
               var port = 8444;
               http.createServer((req, res) => {
                fs.readFile('./sample.html', (err, data) => {
                    if (err) console.log(err);
                        res.writeHead(200, { 'Content-Type': 'text/html' });
                        res.write(data);
                        res.end();
                    });
                }).listen(port);
                console.log('-------------------');
            }
        else {
                /* 
                    5. Write a JSON output to the browser 
                */
            console.log('-------------------');
            console.log('data is in sample.json file!');
            console.log('please open http://localhost:8555 to read the data!');
            var port = 8555;
            http.createServer((req, res) => {
                fs.readFile('./sample.json', (err, data) => {
                    if (err) console.log(err);
                    res.writeHead(200, { 'Content-Type': 'json' });
                    res.write(data);
                    res.end();
                });
            }).listen(port);
            console.log('-------------------');
        };
    }
});